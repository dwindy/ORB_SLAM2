/**
* This file is part of ORB-SLAM2.
*
* Copyright (C) 2014-2016 Raúl Mur-Artal <raulmur at unizar dot es> (University of Zaragoza)
* For more information see <https://github.com/raulmur/ORB_SLAM2>
*
* ORB-SLAM2 is free software: you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* ORB-SLAM2 is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with ORB-SLAM2. If not, see <http://www.gnu.org/licenses/>.
*/

#include "MapPoint.h"
#include "ORBmatcher.h"

#include<mutex>

namespace ORB_SLAM2
{

long unsigned int MapPoint::nNextId=0;
mutex MapPoint::mGlobalMutex;

MapPoint::MapPoint(const cv::Mat &Pos, KeyFrame *pRefKF, Map* pMap):
    mnFirstKFid(pRefKF->mnId), mnFirstFrame(pRefKF->mnFrameId), nObs(0), mnTrackReferenceForFrame(0),
    mnLastFrameSeen(0), mnBALocalForKF(0), mnFuseCandidateForKF(0), mnLoopPointForKF(0), mnCorrectedByKF(0),
    mnCorrectedReference(0), mnBAGlobalForKF(0), mpRefKF(pRefKF), mnVisible(1), mnFound(1), mbBad(false),
    mpReplaced(static_cast<MapPoint*>(NULL)), mfMinDistance(0), mfMaxDistance(0), mpMap(pMap)
{
    Pos.copyTo(mWorldPos);
    mNormalVector = cv::Mat::zeros(3,1,CV_32F);

    // MapPoints can be created from Tracking and Local Mapping. This mutex avoid conflicts with id.
    unique_lock<mutex> lock(mpMap->mMutexPointCreation);
    mnId=nNextId++;

    ///Added module
    label = -1;
    soft = false;
    dynamicObs = 0;
    staticObs = 0;
    ///-------------------
}

MapPoint::MapPoint(const cv::Mat &Pos, Map* pMap, Frame* pFrame, const int &idxF):
    mnFirstKFid(-1), mnFirstFrame(pFrame->mnId), nObs(0), mnTrackReferenceForFrame(0), mnLastFrameSeen(0),
    mnBALocalForKF(0), mnFuseCandidateForKF(0),mnLoopPointForKF(0), mnCorrectedByKF(0),
    mnCorrectedReference(0), mnBAGlobalForKF(0), mpRefKF(static_cast<KeyFrame*>(NULL)), mnVisible(1),
    mnFound(1), mbBad(false), mpReplaced(NULL), mpMap(pMap)
{
    Pos.copyTo(mWorldPos);
    cv::Mat Ow = pFrame->GetCameraCenter();
    mNormalVector = mWorldPos - Ow;
    mNormalVector = mNormalVector/cv::norm(mNormalVector);

    cv::Mat PC = Pos - Ow;
    const float dist = cv::norm(PC);
    const int level = pFrame->mvKeysUn[idxF].octave;
    const float levelScaleFactor =  pFrame->mvScaleFactors[level];
    const int nLevels = pFrame->mnScaleLevels;

    mfMaxDistance = dist*levelScaleFactor;
    mfMinDistance = mfMaxDistance/pFrame->mvScaleFactors[nLevels-1];

    pFrame->mDescriptors.row(idxF).copyTo(mDescriptor);

    // MapPoints can be created from Tracking and Local Mapping. This mutex avoid conflicts with id.
    unique_lock<mutex> lock(mpMap->mMutexPointCreation);
    mnId=nNextId++;

    ///Added module
    label = -1;
    soft = false;
    dynamicObs = 0;
    staticObs = 0;
    //----------------
}

void MapPoint::SetWorldPos(const cv::Mat &Pos)
{
    unique_lock<mutex> lock2(mGlobalMutex);
    unique_lock<mutex> lock(mMutexPos);
    Pos.copyTo(mWorldPos);
}

cv::Mat MapPoint::GetWorldPos()
{
    unique_lock<mutex> lock(mMutexPos);
    return mWorldPos.clone();
}

cv::Mat MapPoint::GetNormal()
{
    unique_lock<mutex> lock(mMutexPos);
    return mNormalVector.clone();
}

KeyFrame* MapPoint::GetReferenceKeyFrame()
{
    unique_lock<mutex> lock(mMutexFeatures);
    return mpRefKF;
}

void MapPoint::AddObservation(KeyFrame* pKF, size_t idx)
{
    unique_lock<mutex> lock(mMutexFeatures);
    if(mObservations.count(pKF))
        return;
    mObservations[pKF]=idx;

    if(pKF->mvuRight[idx]>=0)
        nObs+=2;
    else
        nObs++;
}

    void MapPoint::AddObservationDynamic(KeyFrame *pKF, size_t idx) {
        unique_lock<mutex> lock(mMutexFeatures);
        if (mDynamicObservations.count(pKF))
            return;
        mDynamicObservations[pKF] = idx;

        dynamicObs++;
    }

    void MapPoint::AddObservationStatic(KeyFrame *pKF, size_t idx) {
        unique_lock<mutex> lock(mMutexFeatures);
        if (mStaticObservations.count(pKF))
            return;
        mStaticObservations[pKF] = idx;

        staticObs++;
    }


void MapPoint::EraseObservation(KeyFrame* pKF)
{
    bool bBad=false;
    {
        unique_lock<mutex> lock(mMutexFeatures);
        if(mObservations.count(pKF))
        {
            int idx = mObservations[pKF];
            if(pKF->mvuRight[idx]>=0)
                nObs-=2;
            else
                nObs--;

            mObservations.erase(pKF);

            if(mpRefKF==pKF)
                mpRefKF=mObservations.begin()->first;

            // If only 2 observations or less, discard point
            if(nObs<=2)
                bBad=true;
        }
    }

    if(bBad)
        SetBadFlag();
}

map<KeyFrame*, size_t> MapPoint::GetObservations()
{
    unique_lock<mutex> lock(mMutexFeatures);
    return mObservations;
}

int MapPoint::Observations()
{
    unique_lock<mutex> lock(mMutexFeatures);
    return nObs;
}

void MapPoint::SetBadFlag()
{
    map<KeyFrame*,size_t> obs;
    {
        unique_lock<mutex> lock1(mMutexFeatures);
        unique_lock<mutex> lock2(mMutexPos);
        mbBad=true;
        obs = mObservations;
        mObservations.clear();
    }
    for(map<KeyFrame*,size_t>::iterator mit=obs.begin(), mend=obs.end(); mit!=mend; mit++)
    {
        KeyFrame* pKF = mit->first;
        pKF->EraseMapPointMatch(mit->second);
    }

    mpMap->EraseMapPoint(this);
}

MapPoint* MapPoint::GetReplaced()
{
    unique_lock<mutex> lock1(mMutexFeatures);
    unique_lock<mutex> lock2(mMutexPos);
    return mpReplaced;
}

    void MapPoint::Replace(MapPoint *pMP) {
        if (pMP->mnId == this->mnId)
            return;

        int nvisible, nfound;
        map<KeyFrame *, size_t> obs;
        {
            unique_lock<mutex> lock1(mMutexFeatures);
            unique_lock<mutex> lock2(mMutexPos);
            obs = mObservations;
            mObservations.clear();
            mbBad = true;
            nvisible = mnVisible;
            nfound = mnFound;
            mpReplaced = pMP;
        }

        for (map<KeyFrame *, size_t>::iterator mit = obs.begin(), mend = obs.end(); mit != mend; mit++) {
            // Replace measurement in keyframe
            KeyFrame *pKF = mit->first;

            if (!pMP->IsInKeyFrame(pKF)) {
                pKF->ReplaceMapPointMatch(mit->second, pMP);
                pMP->AddObservation(pKF, mit->second);
                ///Added
                if(pKF->mvKeysDynamics[mit->second])
                    pMP->AddObservationDynamic(pKF, mit->second);
                else
                    pMP->AddObservationStatic(pKF, mit->second);
                ///----------------------------------
            } else {
                pKF->EraseMapPointMatch(mit->second);
            }
        }
        pMP->IncreaseFound(nfound);
        pMP->IncreaseVisible(nvisible);
        pMP->ComputeDistinctiveDescriptors();

        mpMap->EraseMapPoint(this);
    }

bool MapPoint::isBad()
{
    unique_lock<mutex> lock(mMutexFeatures);
    unique_lock<mutex> lock2(mMutexPos);
    return mbBad;
}

void MapPoint::IncreaseVisible(int n)
{
    unique_lock<mutex> lock(mMutexFeatures);
    mnVisible+=n;
}

void MapPoint::IncreaseFound(int n)
{
    unique_lock<mutex> lock(mMutexFeatures);
    mnFound+=n;
}

float MapPoint::GetFoundRatio()
{
    unique_lock<mutex> lock(mMutexFeatures);
    return static_cast<float>(mnFound)/mnVisible;
}

    void MapPoint::ComputeDistinctiveDescriptors() {
        // Retrieve all observed descriptors
        vector<cv::Mat> vDescriptors;

        map<KeyFrame *, size_t> observations;

        {
            unique_lock<mutex> lock1(mMutexFeatures);
            if (mbBad)
                return;
            observations = mObservations;
        }

        if (observations.empty())
            return;

        vDescriptors.reserve(observations.size());

        for (map<KeyFrame *, size_t>::iterator mit = observations.begin(), mend = observations.end();
             mit != mend; mit++) {
            KeyFrame *pKF = mit->first;

            if (!pKF->isBad())
                vDescriptors.push_back(pKF->mDescriptors.row(mit->second));
        }

        if (vDescriptors.empty())
            return;

        // Compute distances between them
        const size_t N = vDescriptors.size();

        float Distances[N][N];
        for (size_t i = 0; i < N; i++) {
            Distances[i][i] = 0;
            for (size_t j = i + 1; j < N; j++) {
                int distij = ORBmatcher::DescriptorDistance(vDescriptors[i], vDescriptors[j]);
                Distances[i][j] = distij;
                Distances[j][i] = distij;
            }
        }

        // Take the descriptor with the least median distance to the rest
        int BestMedian = INT_MAX;
        int BestIdx = 0;
        for (size_t i = 0; i < N; i++) {
            vector<int> vDists(Distances[i], Distances[i] + N);//Note N-1?
            sort(vDists.begin(), vDists.end());
            int median = vDists[0.5 * (N - 1)];

            if (median < BestMedian) {
                BestMedian = median;
                BestIdx = i;
            }
        }

        {
            unique_lock<mutex> lock(mMutexFeatures);
            mDescriptor = vDescriptors[BestIdx].clone();
        }
    }

cv::Mat MapPoint::GetDescriptor()
{
    unique_lock<mutex> lock(mMutexFeatures);
    return mDescriptor.clone();
}

int MapPoint::GetIndexInKeyFrame(KeyFrame *pKF)
{
    unique_lock<mutex> lock(mMutexFeatures);
    if(mObservations.count(pKF))
        return mObservations[pKF];
    else
        return -1;
}

bool MapPoint::IsInKeyFrame(KeyFrame *pKF)
{
    unique_lock<mutex> lock(mMutexFeatures);
    return (mObservations.count(pKF));
}

/*
 * Normalized all the observation vector
 */
    void MapPoint::UpdateNormalAndDepth() {
        map<KeyFrame *, size_t> observations;
        KeyFrame *pRefKF;
        cv::Mat Pos;
        {
            unique_lock<mutex> lock1(mMutexFeatures);
            unique_lock<mutex> lock2(mMutexPos);
            if (mbBad)
                return;
            observations = mObservations;
            pRefKF = mpRefKF;
            Pos = mWorldPos.clone();
        }

        if (observations.empty())
            return;

        cv::Mat normal = cv::Mat::zeros(3, 1, CV_32F);
        int n = 0;
        for (map<KeyFrame *, size_t>::iterator mit = observations.begin(), mend = observations.end();
             mit != mend; mit++) {
            KeyFrame *pKF = mit->first;
            cv::Mat Owi = pKF->GetCameraCenter();
            cv::Mat normali = mWorldPos - Owi;
            normal = normal + normali / cv::norm(normali);
            n++;
        }

        cv::Mat PC = Pos - pRefKF->GetCameraCenter();
        const float dist = cv::norm(PC);
        const int level = pRefKF->mvKeysUn[observations[pRefKF]].octave;
        const float levelScaleFactor = pRefKF->mvScaleFactors[level];
        const int nLevels = pRefKF->mnScaleLevels;

        {
            unique_lock<mutex> lock3(mMutexPos);
            mfMaxDistance = dist * levelScaleFactor;
            mfMinDistance = mfMaxDistance / pRefKF->mvScaleFactors[nLevels - 1];
            mNormalVector = normal / n;
        }
    }

    void calcMeanVariance(vector<float> dists, float &mean, float &variance) {
        if (dists.size() <= 1) {
            mean = dists[0];
            variance = 0;
        } else {
            float sum = std::accumulate(dists.begin(), dists.end(), 0.0);
            mean = sum / dists.size();
            double sumOfSquares = 0.0;
            for (float dist: dists)
                sumOfSquares += std::pow(dist - mean, 2);
            variance = sumOfSquares / (dists.size() - 1);
        }
    }

    ///adds on
    /* Because the depth is a predicted depth, we hope to remove/update the depth by check the consistency of depth
     * for example, if a MapPoint MP would be observed from frame 1,2,3,4...
     * unproject 2d pt_1, pt_2, pt_3 and pt_4 to world Frame, to get P3d_1, P3d_2,P3d_3,P3d_4.
     * transform P3d_1 to frame2, get P3d^2_1, project to image get pt^2_1.
     * get the distance of pt_2 and pt^2_1, and pt_3 and pt^3_1, pt_4 and pt^4_1 as well.
     * get the median distance. of above four errors.
     * Now we have a error matrix of 4x4.
     * two Options, 1.each row represents the goodness of this observation, replace the MP with that row.
     * 2.the variance of this matrix represents the consistency of this MP.
     *
     */
    void MapPoint::UpdateDetphZoe() {
        ///Get all the observations of this MapPoint
        map<KeyFrame *, size_t> observations;
        KeyFrame *pRefKF;
        cv::Mat Pos;
        {
            unique_lock<mutex> lock1(mMutexFeatures);
            unique_lock<mutex> lock2(mMutexPos);
            if (mbBad)
                return;
            observations = mObservations;
            pRefKF = mpRefKF;
            Pos = mWorldPos.clone();
        }
        if (observations.empty())
            return;

        ///Unprojecting from each frame to world frame
        vector<cv::Mat> all3D;//under world frame
        vector<KeyFrame *> allKeyFrames;
        for (auto &observation: observations) {
            KeyFrame *pKF = observation.first;
            unsigned long index = observation.second;
            //float depth = pKF->mvDepth[index];
            all3D.push_back(pKF->UnprojectStereo(index));
            allKeyFrames.push_back(pKF);
        }
        int N = all3D.size();

        ///Transform from world to other frame to calc the uv error
        float Distances[N][N];
        for (int i = 0; i < all3D.size(); i++) {
            Distances[i][i] = 0;
//            //Get Rotation, translation of Frame i
//            KeyFrame *pKFi = allKeyFrames[i];
//            int index = observations.at(pKFi);
//            cv::Mat Riw = pKFi->GetRotation();
//            cv::Mat tiw = pKFi->GetTranslation();
//            cv::Mat Tiw;
//            Tiw.rowRange(0, 3).colRange(0, 3) = Riw;
//            Tiw.col(3).rowRange(0, 3) = tiw;
            cv::Mat p3d_i = cv::Mat(4, 1, CV_32F);
            p3d_i.at<float>(0, 0) = all3D[i].at<float>(0, 0);
            p3d_i.at<float>(1, 0) = all3D[i].at<float>(1, 0);
            p3d_i.at<float>(2, 0) = all3D[i].at<float>(2, 0);
            p3d_i.at<float>(3, 0) = 1.0f;
            for (size_t j = i + 1; j < N; j++) {
                //Get Rotation, translation of Frame j
                KeyFrame *pKFj = allKeyFrames[j];
                int indexj = observations.at(pKFj);
                cv::Mat Rjw = pKFj->GetRotation();
                cv::Mat tjw = pKFj->GetTranslation();
                //Project from world to j.
                cv::Mat Tjw = cv::Mat::ones(4,4,CV_32F);
                Tjw.rowRange(0, 3).colRange(0, 3) = Rjw;
                Tjw.col(3).rowRange(0, 3) = tjw;
                cv::Mat P3Dj = Tjw * p3d_i;
                //todo distortion?
                cv::Mat p2d = pKFj->Project2Image(P3Dj);
                //todo key.pt should involves with octiave?
                //Distance
                cv::KeyPoint pt_obs = pKFj->mvKeysUn[indexj];
                float distance = (pt_obs.pt.x - p2d.at<float>(0, 0)) * (pt_obs.pt.x - p2d.at<float>(0, 0))
                                 + (pt_obs.pt.y - p2d.at<float>(1, 0)) * (pt_obs.pt.y - p2d.at<float>(1, 0));
                Distances[i][j] = distance;
                Distances[j][i] = distance;
            }
        }

        ///Select the position with mean that has the least variance
        // Take the descriptor with the least median distance to the rest
        int BestMedian = INT_MAX;
        int BestIdx = 0;
        for (size_t i = 0; i < N; i++) {
            vector<float> vDists(Distances[i], Distances[i] + N-1);//Note N-1?
            sort(vDists.begin(), vDists.end());
            //float mean = 0, variance = 0;
            //calcMeanVariance(vDists, mean, variance);
            int median = vDists[0.5 * (N - 1)];
            if(median < BestMedian){
                BestIdx = i;
                BestMedian = median;
            }
        }
        //Apply Best Median 3d Point to
        {
            unique_lock<mutex> lock(mMutexFeatures);
            cv::Mat P3Dc = all3D[BestIdx];
            this->mWorldPos = P3Dc;
            //todo compare with erasing way
        }
    }

    /*
     * this function used to update the dynamic rate of this mappoint
     * by counting the dynamic frame / all observed frame
     */
    void MapPoint::UpdateDynamicRate(){

    }

float MapPoint::GetMinDistanceInvariance()
{
    unique_lock<mutex> lock(mMutexPos);
    return 0.8f*mfMinDistance;
}

float MapPoint::GetMaxDistanceInvariance()
{
    unique_lock<mutex> lock(mMutexPos);
    return 1.2f*mfMaxDistance;
}

int MapPoint::PredictScale(const float &currentDist, KeyFrame* pKF)
{
    float ratio;
    {
        unique_lock<mutex> lock(mMutexPos);
        ratio = mfMaxDistance/currentDist;
    }

    int nScale = ceil(log(ratio)/pKF->mfLogScaleFactor);
    if(nScale<0)
        nScale = 0;
    else if(nScale>=pKF->mnScaleLevels)
        nScale = pKF->mnScaleLevels-1;

    return nScale;
}

int MapPoint::PredictScale(const float &currentDist, Frame* pF)
{
    float ratio;
    {
        unique_lock<mutex> lock(mMutexPos);
        ratio = mfMaxDistance/currentDist;
    }

    int nScale = ceil(log(ratio)/pF->mfLogScaleFactor);
    if(nScale<0)
        nScale = 0;
    else if(nScale>=pF->mnScaleLevels)
        nScale = pF->mnScaleLevels-1;

    return nScale;
}



} //namespace ORB_SLAM
